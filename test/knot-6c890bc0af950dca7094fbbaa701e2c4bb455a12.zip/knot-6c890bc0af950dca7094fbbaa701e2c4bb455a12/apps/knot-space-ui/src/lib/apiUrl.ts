import { PUBLIC_BACKEND_URL } from "$env/static/public";

export const BACKEND_URL = PUBLIC_BACKEND_URL;

export default BACKEND_URL;
