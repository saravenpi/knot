import React from 'react'
import './App.css'

function App() {
  return (
    <div className="App">
      <h1>Hello {{name}}!</h1>
      <p>Welcome to your new Knot app built with React and Vite.</p>
    </div>
  )
}

export default App