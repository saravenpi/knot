<script>
	const name = '{{name}}';
</script>

<h1>Welcome to {name}!</h1>
<p>This is your new SvelteKit app created with Knot CLI.</p>

<style>
	h1 {
		color: #333;
		text-align: center;
		margin: 2rem 0;
	}
	
	p {
		text-align: center;
		color: #666;
	}
</style>