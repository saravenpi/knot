/**
 * Main entry point for the package
 */
export function hello(name: string): string {
    return `Hello, ${name}!`;
}

export default hello;